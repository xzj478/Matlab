A = [1 2; 3 4];
whos
  Name      Size            Bytes  Class     Attributes

  A         2x2                32  double              

a = 3;
whos
  Name      Size            Bytes  Class     Attributes

  A         2x2                32  double              
  a         1x1                 8  double              

class(A)

ans =

    'double'

class(a)

ans =

    'double'

b = 'Hello';
class(b)

ans =

    'char'

% some function related to char object
% disp
disp(c)
{Undefined function or variable 'c'.
} 
disp(b)
Hello
disp(a)
     3

disp(A)
     1     2
     3     4

A

A =

     1     2
     3     4

% other output functions
fprintf('Hello')
Hellofprintf('Hello\n')
Hello
a = 1;
b = 'World';
c = 'Michael';
fprintf('%s %s %d', b c a)
 fprintf('%s %s %d', b c a)
                       ↑
{Error: Invalid expression. Check for missing multiplication operator, missing or unbalanced delimiters, or other syntax error. To
construct matrices, use brackets instead of parentheses.
} 
fprintf('%s %s %d', b, c, a)
World Michael 1fprintf('%s %s %d\n', b, c, a)
World Michael 1
num2str(a)

ans =

    '1'

class(a)

ans =

    'double'

a

a =

     1

num2str(a)

ans =

    '1'

a

a =

     1

class(a)

ans =

    'double'

a = 'hello';
b = 'student';
c = 'your mark is';
d = 9;
[a, b, c, d]

ans =

    'hellostudentyour mark is	'

[a, b, c, num2str(d)]

ans =

    'hellostudentyour mark is9'

[a, b, c,  num2str(d)]

ans =

    'hellostudentyour mark is9'

[a'', b'', c'', num2str(d)] 

ans =

    'hellostudentyour mark is9'

[a ' ', b ' ', c ' ', num2str(d)]

ans =

    'hello student your mark is 9'

% data structure
student.name = 'Zijian';
student.surname = 'Xie';
student.age = 20;
student.home_country = 'China';
student

student = 

  <a href="matlab:helpPopup struct" style="font-weight:bold">struct</a> with fields:

            name: 'Zijian'
         surname: 'Xie'
             age: 20
    home_country: 'China'

student(2).name = 'Jishu';
student(2).surname = 'Huang';
student(2).age = 20;
student(2).home_country = 'China';
student(2)

ans = 

  <a href="matlab:helpPopup struct" style="font-weight:bold">struct</a> with fields:

            name: 'Jishu'
         surname: 'Huang'
             age: 20
    home_country: 'China'

student

student = 

  1×2 <a href="matlab:helpPopup struct" style="font-weight:bold">struct</a> array with fields:

    name
    surname
    age
    home_country

% how to access structure field
student(1).name

ans =

    'Zijian'

% Cell matrix, array
% example about non-cell array
a = [1 2; 3 4]

a =

     1     2
     3     4

b = ['A', 'B', 'C', 'D']

b =

    'ABCD'

b = ['A', 'B'; 'C', 'D']

b =

  2×2 <a href="matlab:helpPopup char" style="font-weight:bold">char</a> array

    'AB'
    'CD'

{'Hello', [1 2; 3 4], student}

ans =

  1×3 <a href="matlab:helpPopup cell" style="font-weight:bold">cell</a> array

    {'Hello'}    {2×2 double}    {1×2 struct}

A = [1 2];
B = [1 2; 3 4];
C = [1 2 3; 4 5 6];
b = {A, B, C}

b =

  1×3 <a href="matlab:helpPopup cell" style="font-weight:bold">cell</a> array

    {1×2 double}    {2×2 double}    {2×3 double}

% How to access to the cell elements
a

a =

     1     2
     3     4

A

A =

     1     2

b{1}

ans =

     1     2

a = 'mike';
b = 'mary';
c = 'tim';
[a,b,c]

ans =

    'mikemarytim'

[a' ',b' ',c]
 [a' ',b' ',c]
          ↑
{Error: Character vector is not terminated properly.
} 
[a' ',b' ',c' ']
 [a' ',b' ',c' ']
               ↑
{Error: Character vector is not terminated properly.
} 
[a' ', b' ', c]
 [a' ', b' ', c]
           ↑
{Error: Character vector is not terminated properly.
} 
% converting cell to struct, struct to cell
marks.math = 10;
marks.physics = 10;
marks.electronics = 10;
struct2cell(marks)

ans =

  3×1 <a href="matlab:helpPopup cell" style="font-weight:bold">cell</a> array

    {[10]}
    {[10]}
    {[10]}

fieldnames(marks)

ans =

  3×1 <a href="matlab:helpPopup cell" style="font-weight:bold">cell</a> array

    {'math'       }
    {'physics'    }
    {'electronics'}

marks{10 10 10};
 marks{10 10 10};
          ↑
{Error: Invalid expression. Check for missing multiplication operator, missing or unbalanced delimiters, or other syntax error. To
construct matrices, use brackets instead of parentheses.
} 
marks = {10 10 10};
courses = {'math', 'physics', 'electronics'};
cell2struct(marks,courses,2)

ans = 

  <a href="matlab:helpPopup struct" style="font-weight:bold">struct</a> with fields:

           math: 10
        physics: 10
    electronics: 10

diary off
