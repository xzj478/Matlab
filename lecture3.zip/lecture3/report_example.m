% first lab processing measurement data
t = 0:0.01:2*pi;
y = sin(t);
plot(t,y);
xlabel('time,s');
ylabel('signal');
title('my first graph');
% conclusion:
% what have I learned in this lab